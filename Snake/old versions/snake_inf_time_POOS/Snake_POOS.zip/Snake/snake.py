import pygame
import time
import random
import sys
from pygame import mixer


print("-"*30)

print("-"*30)
game_mode = sys.argv[1] if len(sys.argv) > 1 else "classic"

print("Game Mode : ",game_mode )

print(" -"*10)
difficulty = eval(sys.argv[2]) if len(sys.argv) > 2 else 2

print("Difficulty : ", difficulty)

print(" -"*10)
game_music_id = sys.argv[3] if len(sys.argv) > 3 else "classic"
game_music_name = "gfunk" if game_music_id == "g" else game_music_id

print("Game Music : ",game_music_name )

print(" -"*10)
music_volume = eval(sys.argv[4])/100 if len(sys.argv) > 4 else 0.4

print("Music Volume : ", int(music_volume*100), "%")

print("-"*30)

print("-"*30)

if "info" in game_mode :
    
    print("Game Modes : \n --> infinity : Wrap around edges\n --> god : Be invincible and compete for points")
    
    print("-"*30)
    
    print("Game Difficulty : \n --> 1 : Normal\n --> 2 : Hard\n --> 3 : Good Luck\n (decimals are accepted)")
    
    print("-"*30)
    
    print("Game Themes : \n --> classic\n --> epic\n --> gfunk\n --> retro\n --> metal\n --> chill")
    
    print("-"*30)
    
    print("-"*30)

pygame.init()

global_score_B = 0
global_score_W = 0


# Graphics 
white = (255, 255, 255)
yellow =(255,255,0)
grey = (100,100,100)
purple = (75,0,130)
black = (0, 0, 0)
red = (213, 50, 80)
green1 = (0, 255, 0)
green2 = (40, 215, 40)
green_bonus = (0,150,0)
blue = (50, 153, 213)
blue_freeze = (0,0,255)

snake_block = 20
snake_speed = 10*difficulty

display_width = 60*snake_block
display_height = 40*snake_block

dis = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption('Snake Game')
clock = pygame.time.Clock()

font_end = pygame.font.SysFont(None, 40)
font_win = pygame.font.SysFont(None, 40)

shield_ico = pygame.transform.scale(pygame.image.load("graphics/shield_ico.png"), (snake_block*3, snake_block*3))
speed_ico = pygame.transform.scale(pygame.image.load("graphics/speed_ico.png"), (snake_block*3, snake_block*3))
growth_ico = pygame.transform.scale(pygame.image.load("graphics/growth_ico.png"),(snake_block*3, snake_block*3))
magnet_ico = pygame.transform.scale(pygame.image.load("graphics/magnet_ico.png"), (snake_block*3, snake_block*3))
reverse_ico = pygame.transform.scale(pygame.image.load("graphics/reverse_ico.png"), (snake_block*3, snake_block*3))
freeze_ico = pygame.transform.scale(pygame.image.load("graphics/freeze_ico.png"), (snake_block*3, snake_block*3))

pommeV_ico = pygame.transform.scale(pygame.image.load("graphics/pommeV_ico.png"), (snake_block, snake_block))
pommeR_ico = pygame.transform.scale(pygame.image.load("graphics/pommeR_ico.png"), (snake_block, snake_block))

snake1_ico = pygame.transform.scale(pygame.image.load("graphics/python_ico.png"), (snake_block*2, snake_block*2))
snake2_ico = pygame.transform.scale(pygame.image.load("graphics/python_ico.png"), (snake_block*2, snake_block*2))

# Audio 
mixer.init()
eating_sound = mixer.Sound('sounds/crunch.wav')
powerup_sound = mixer.Sound('sounds/powerup.wav')
# Load main theme 
if game_music_name == "retro" :
    game_theme_music_path = "retro_theme.wav" 
else :
    game_theme_music_path = game_music_name+"_theme.mp3"
game_theme_music_path = "sounds/"+game_theme_music_path
pygame.mixer.music.load(game_theme_music_path)


# Modifiers
powerup_types = [{'name': 'Invincible', 'color': grey, 'duration': 10, 'icon': shield_ico},
                 {'name': 'Speed Boost', 'color': yellow, 'duration': 7, 'icon': speed_ico},
                 {'name': 'Growth Multiplier', 'color': green_bonus, 'duration': 8, 'icon': growth_ico},
                 {'name': 'Magnet', 'color': red, 'duration': 10, 'icon': magnet_ico},
                 {'name': 'Reverse', 'color': purple, 'duration': 5, 'icon': reverse_ico},
                 {'name': 'Freeze', 'color': blue_freeze, 'duration': 5, 'icon': freeze_ico}]



def message(msg, color):
    mesg = font_end.render(msg, True, color)
    dis.blit(mesg, [display_width / 4, display_height / 3])
    
def show_scores(snake1,snake2,font_score, final=False, font_win=font_win):
    # Update scores
    score1 = snake1.length
    score2 = snake2.length
    
    # Draw scores on top of screen
    text_score1 = font_score.render(f"Black Score: {score1}", True, white)
    text_score2 = font_score.render(f"White Score: {score2}", True, white)
    dis.blit(text_score2, (10, 10))
    dis.blit(text_score1, (display_width - text_score2.get_width() - 10, 10))

    if final :
        # Update scores
        score1 = global_score_B
        score2 = global_score_W
        
        # Draw scores on top of screen
        text_win1 = font_win.render(f"Black Wins: {score1}", True, white)
        text_win2 = font_win.render(f"White Wins: {score2}", True, white)
        dis.blit(text_win2, (30, 30))
        dis.blit(text_win1, (display_width - text_score2.get_width() - 90, 30))
            

def show_timer(snake, color, time_left, name="-"):
    # Show Power up name :
    type = font_win.render(f"{name}", True, color)

    font_style = pygame.font.SysFont(None, 80)
    timer_text = str(int(time_left)).zfill(2)
    time = font_style.render(timer_text, True, color)
    if snake.player_name == 'Black':
        dis.blit(time, (display_width - time.get_width() - 10, 50))
        dis.blit(type, (display_width - type.get_width() - 10, 100))
    else:
        dis.blit(time, (10, 50))
        dis.blit(type, (10, 100))

def show_game_timer(time_left):
    # Show time left if time mode activated 
    if 'time' in game_mode:
        font_style = pygame.font.SysFont(None, 80)
        timer_text = str(int(time_left)).zfill(2)
        time = font_style.render(timer_text, True, red)
        dis.blit(time, (display_width//2, 30))
     
class Snake:
    def __init__(self, x, y, player_name, controls):
        self.x = x
        self.y = y
        self.x_change = 0
        self.y_change = 0
        self.snake_list = []
        self.length = 1
        self.player_name = player_name
        self.controls = controls
        self.reset_power_up_variators()

    def reset_power_up_variators(self):
        self.powerup_time = None
        self.growth_multiplier = 1
        self.magnet = 1
        self.control_variation = 1
        self.movement_variation = 1
        if 'god' in game_mode:
            self.state = 'invincible'
        else :
            self.state = 'normal'

    def handle_events(self, events):
        # We consider only the last event in player keys that were pressed
        events = [event for event in events if event.type != pygame.QUIT and event.key in list(self.controls.values()) ][-1:]
        for event in events :
            if self.control_variation != 0 :
                if event.key == self.controls['left'] and self.x_change == 0:
                    self.x_change = -snake_block*self.control_variation
                    self.y_change = 0
                elif event.key == self.controls['right'] and self.x_change == 0:
                    self.x_change = snake_block*self.control_variation
                    self.y_change = 0
                elif event.key == self.controls['up'] and self.y_change == 0:
                    self.y_change = -snake_block*self.control_variation
                    self.x_change = 0
                elif event.key == self.controls['down'] and self.y_change == 0:
                    self.y_change = snake_block*self.control_variation
                    self.x_change = 0

    def move(self):
        self.x += self.movement_variation*self.x_change
        self.y += self.movement_variation*self.y_change
    

    def is_out_of(self, x_max, y_max):
        return self.x >= x_max or self.x < 0 or self.y >= y_max or self.y < 0
        
    
    def check_edge_collision(self):
        if 'infinity' in game_mode or 'invincible' in self.state:
            # Wrap around the screen for player 
            self.x %= display_width
            self.y %= display_height
            hit_edges = False
            return hit_edges, "No Winner"
        else :
            # Check for out of bounds for player (only in classic mode)
            if self.is_out_of(display_width,display_height) :
                hit_edges = True
                winner = self.player_name
                return hit_edges, winner
            else :
                hit_edges = False
                return hit_edges, "No Winner"
            
    def eat_powerup(self, powerup_x, powerup_y, powerup_active, powerup_type, players):
        if abs(self.x - powerup_x) < self.magnet*2*snake_block and abs(self.y - powerup_y) < self.magnet*2*snake_block and powerup_active:
                self.powerup_time = time.time()  # set power-up time for player 1
                powerup_sound.play()
                if powerup_type['name'] == 'invincible':
                    self.state += 'invincible'
                elif powerup_type['name'] == 'speed boost':
                    self.state = 'speed boost'
                    self.movement_variation *=2
                    self.magnet = 2
                elif powerup_type['name'] == 'growth multiplier':
                    self.growth_multiplier = 3
                elif powerup_type['name'] == 'magnet':
                    self.magnet = 5
                elif powerup_type['name'] == 'reverse':
                    for snake in players.remove(self):
                        snake.control_variation *= -1
                elif powerup_type['name'] == 'freeze':
                    for snake in players.remove(self):
                        snake.movement_variation = 0
                        snake.state += 'invincible'
                powerup_type = None
        return powerup_type
    
    def check_powerup_duration(self, players, powerup_active, POWERUP_DURATION):
            
        if self.powerup_time is not None and time.time() - self.powerup_time >= POWERUP_DURATION:
            for snake in players :
                snake.reset_power_up_variators()
            powerup_active = False 
        
        return powerup_active
            

def gameLoop():

    global global_score_B 
    global global_score_W

    pygame.mixer.music.play(-1) 
    pygame.mixer.music.set_volume(music_volume)
    
    #print("Game Loop")
    game_over = False
    game_close = False

    #print(game_close)
    #print(" Player 1 Snake")
    P1_keys = {'left' : pygame.K_LEFT, 'right' : pygame.K_RIGHT, 'up' : pygame.K_UP, 'down' : pygame.K_DOWN}
    snake1 = Snake(3*display_width//4, 3*display_height//4, 'Black', P1_keys)

    #print(game_close)
    #print(" Player 2 Snake")
    P2_keys = [pygame.K_z, pygame.K_q, pygame.K_s, pygame.K_d]
    P2_keys = {'left' : pygame.K_q, 'right' : pygame.K_d, 'up' : pygame.K_z, 'down' : pygame.K_s}
    snake2 = Snake(display_width//4, display_height//4, 'White', P2_keys)
    
    players = [snake1, snake2]
   
    #print(game_close)
    #print(" Food")
    foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block

    food2x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    food2y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
    food2_exist = True

    foodRx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    foodRy = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
    foodR_exist = True
    
    #print(game_close)
    #print(" Power ups")
    powerup_chance = 0.05
    powerup_timer = 0
    power_up_name = ''
    POWERUP_DURATION = 0 
    powerup_active = False
    powerup_type = None
    powerup_x = None
    powerup_y = None
    snake1.powerup_time = None
    snake2.powerup_time = None

    

    # Set up font objects
    font_score = pygame.font.SysFont(None, 25)
    font_winner = pygame.font.SysFont(None, 30)
    
    # Set up timer 
    start_time = time.time()
    max_time = 60*snake_block

    winner = ""
    while not game_over:
        # If game has ended, add winner score
        if game_close :
            if winner == "Black":
                global_score_B +=1
            if winner == "White":
                global_score_W +=1

        while game_close:
            #dis.fill(blue)
            message(winner+" Player Wins! Press E-Exit or C-Play Again", red)

            show_scores(snake1,snake2,font_score, final=True)
            pygame.mixer.music.stop()
            pygame.display.update()

            events =  pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    game_over = True
                    game_close = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_e:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        gameLoop()
                        
        #print(game_close)
        #print(" Handle events")
        events = [event for event in pygame.event.get() if event.type == pygame.QUIT or event.type == pygame.KEYDOWN]
        snake1.handle_events(events)
        snake2.handle_events(events)
        quit_event = [event for event in events if event.type == pygame.QUIT]
        for event in quit_event:
            if event.type == pygame.QUIT:
                game_over = True
        
                    
        #print(game_close)
        #print("Power ups")
        #print(game_close)
        #print(powerup_active)

        if not powerup_active and random.random() < powerup_chance:
            powerup_type = random.choice(powerup_types)
            powerup_x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            powerup_y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            powerup_active = True
            power_up_name = powerup_type['name']
            power_up_color = powerup_type['color']
            powerup_icon = powerup_type['icon']
            powerup_timer = powerup_type['duration'] * snake_speed
            POWERUP_DURATION = powerup_type['duration'] 

        dis.fill(blue)
        for snake in players :
            snake.move()

        for snake in players :
            edge_hit, winner = snake.check_edge_collision()
            if edge_hit == True :
                game_close = True
                break
        
        

        
        #print(game_close)
        #print(" update snake 1 and check for collision with player 2")
        if snake1.movement_variation != 0 :
            snake_Head1 = [snake1.x, snake1.y]
            snake1.snake_list.append(snake_Head1)

        while len(snake1.snake_list) > snake1.length:
            del snake1.snake_list[0]

            
        for x in snake1.snake_list[:-1]:
            if x == snake_Head1 and 'invincible' not in snake1.state :
                    game_close = True
                    winner = "White"
                    #print("Hit himself")
                    
        for x in snake2.snake_list[:-1]:
            if x == snake_Head1 and 'invincible' not in snake1.state :
                    game_close = True
                    winner = "White"
                    #print("Hit Other")
                    

        for x in snake1.snake_list:
            pygame.draw.rect(dis, black, [x[0], x[1], snake_block, snake_block])
        dis.blit(snake1_ico, (snake1.x-snake_block//2, snake1.y-snake_block//2))

        #print(game_close)
        #print(" update snake 2 and check for collision with player 1")
        if snake2.movement_variation != 0 :
            snake_Head2 = [snake2.x, snake2.y]
            snake2.snake_list.append(snake_Head2)

        while len(snake2.snake_list) > snake2.length:
            del snake2.snake_list[0]

        for x in snake2.snake_list[:-1]:
            if x == snake_Head2 and 'invincible' not in snake2.state :
                    game_close = True
                    winner = "Black"
                    #print("Hit himself")
                    
        for x in snake1.snake_list[:-1]:
            if x == snake_Head2 and 'invincible' not in snake2.state :
                    game_close = True
                    winner = "Black"
                    #print("Hit Other")
                    
                    

        for x in snake2.snake_list:
            pygame.draw.rect(dis, white, [x[0], x[1], snake_block, snake_block])
        dis.blit(snake2_ico, (snake2.x-snake_block//2, snake2.y-snake_block//2))

        
        max_time -= 1
        show_game_timer((max_time - (time.time()-start_time))//snake_block)

        if (max_time - (time.time()-start_time)) < 0 and 'time' in game_mode:
            if snake1.length > snake2.length :
                winner = 'Black'
            elif snake1.length < snake2.length :
                winner = 'White'
            else :
                winner = "No"
            game_close = True



        #print(game_close)
        #print(" draw food on the screen")
        #pygame.draw.rect(dis, green1, [foodx, foody, snake_block, snake_block])
        #pygame.draw.rect(dis, green2, [food2x, food2y, snake_block, snake_block])
        dis.blit(pommeV_ico, (foodx, foody))
        dis.blit(pommeV_ico, (food2x, food2y))
        dis.blit(pommeR_ico, (foodRx, foodRy))
        

        #print(game_close)
        #print(" handle power ups")
        #if powerup_active and powerup_type != None:
        #    pygame.draw.rect(dis, powerup_type['color'], [powerup_x, powerup_y, snake_block, snake_block])
        if powerup_active and powerup_type != None:
            dis.blit(powerup_icon, (powerup_x-snake_block, powerup_y-snake_block))
            powerup_timer -= 1
            if powerup_timer <= 0:
                powerup_active = False
                powerup_type = None

            for snake in players :
                powerup_type = snake.eat_powerup(powerup_x, powerup_y, powerup_active, powerup_type, players)

        # check power-up effect duration for player 1
        for snake in players :
            powerup_still_active = snake.check_powerup_duration(players, powerup_active, POWERUP_DURATION)
        powerup_active = powerup_still_active
            

        # show power-up timer if active
        if powerup_active and snake1.powerup_time is not None:
            show_timer(snake1,power_up_color,POWERUP_DURATION - (time.time() - snake1.powerup_time), name=power_up_name)
        elif powerup_active and snake2.powerup_time is not None:
            show_timer(snake2,power_up_color,POWERUP_DURATION - (time.time() - snake2.powerup_time), name=power_up_name)
            
        # Update scores
        show_scores(snake1,snake2,font_score)

        #print(game_close)
        #print(" update display")
        pygame.display.update()
        
        #print(game_close)
        #print(" check for food collision for player 1")
        if abs(snake1.x - foodx) < snake1.magnet*snake_block and abs(snake1.y - foody) < snake1.magnet*snake_block:
            foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            eating_sound.play()
            snake1.length += snake1.growth_multiplier*3

        #print(game_close)
        #print(" check for food collision for player 2")
        if abs(snake2.x - foodx) < snake2.magnet*snake_block and abs(snake2.y - foody) < snake2.magnet*snake_block:
            foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            eating_sound.play()
            snake2.length += snake2.growth_multiplier*3

        if food2_exist:
            if abs(snake1.x - food2x) < snake1.magnet*snake_block and abs(snake1.y - food2y) < snake1.magnet*snake_block:
                food2_exist = False
                eating_sound.play()
                snake1.length += snake1.growth_multiplier*3

            if abs(snake2.x - food2x) < snake2.magnet*snake_block and abs(snake2.y - food2y) < snake2.magnet*snake_block:
                food2_exist = False
                eating_sound.play()
                snake2.length += snake2.growth_multiplier*3

        if foodR_exist:
            if abs(snake1.x - foodRx) < snake1.magnet*snake_block and abs(snake1.y - foodRy) < snake1.magnet*snake_block and 'invincible' not in snake2.state :
                foodR_exist = False
                eating_sound.play()
                snake2.length = max(1,snake2.length-(max(1,snake1.growth_multiplier-1))*2)

            if abs(snake2.x - foodRx) < snake2.magnet*snake_block and abs(snake2.y - foodRy) < snake2.magnet*snake_block and 'invincible' not in snake1.state :
                foodR_exist = False
                eating_sound.play()
                snake1.length = max(1,snake1.length-(max(1,snake2.growth_multiplier-1))*2) 
                
        if not food2_exist:
            food2x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            food2y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            food2_exist = True
        
        if not foodR_exist:
            foodRx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foodRy = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            foodR_exist = True
                
        #print(game_close)
        print(snake1.state, snake2.state)
        #print(" check for collision between snake heads")
        if snake1.x == snake2.x and snake1.y == snake2.y and 'invincible' not in snake1.state  and 'invincible' not in snake2.state :
            if snake1.length > snake2.length :
                winner = 'Black'
                
            elif snake1.length < snake2.length :
                winner = 'White'
                
            else :
                winner = "No"
            game_close = True
            
        clock.tick(snake_speed)

        

    pygame.quit()
gameLoop()
