import pygame
import time
import random
import sys
from pygame import mixer

print("-"*30)
print("-"*30)
game_mode = sys.argv[1] if len(sys.argv) > 1 else "classic"
print("Game Mode : ",game_mode )
print(" -"*10)
difficulty = eval(sys.argv[2]) if len(sys.argv) > 2 else 2
print("Difficulty : ", difficulty)
print(" -"*10)
game_music_id = sys.argv[3] if len(sys.argv) > 3 else "classic"
game_music_name = "gfunk" if game_music_id == "g" else game_music_id
print("Game Music : ",game_music_name )
print(" -"*10)
music_volume = eval(sys.argv[4])/100 if len(sys.argv) > 4 else 0.4
print("Music Volume : ", int(music_volume*100), "%")
print("-"*30)
print("-"*30)

if "info" in game_mode :
    print("Game Modes : \n --> infinity : Wrap around edges\n --> god : Be invincible and compete for points")
    print("-"*30)
    print("Game Difficulty : \n --> 1 : Normal\n --> 2 : Hard\n --> 3 : Good Luck\n (decimals are accepted)")
    print("-"*30)
    print("Game Themes : \n --> classic\n --> epic\n --> gfunk\n --> retro\n --> metal\n --> chill")
    print("-"*30)
    print("-"*30)

pygame.init()

global_score_B = 0
global_score_W = 0


# Graphics 
white = (255, 255, 255)
yellow =(255,255,0)
grey = (100,100,100)
purple = (75,0,130)
black = (0, 0, 0)
red = (213, 50, 80)
green1 = (0, 255, 0)
green2 = (40, 215, 40)
green_bonus = (0,150,0)
blue = (50, 153, 213)
blue_freeze = (0,0,255)

snake_block = 20
snake_speed = 10*difficulty

display_width = 60*snake_block
display_height = 40*snake_block

dis = pygame.display.set_mode((display_width, display_height))
pygame.display.set_caption('Snake Game')
clock = pygame.time.Clock()

font_end = pygame.font.SysFont(None, 40)
font_win = pygame.font.SysFont(None, 40)

shield_ico = pygame.transform.scale(pygame.image.load("graphics/shield_ico.png"), (snake_block*3, snake_block*3))
speed_ico = pygame.transform.scale(pygame.image.load("graphics/speed_ico.png"), (snake_block*3, snake_block*3))
growth_ico = pygame.transform.scale(pygame.image.load("graphics/growth_ico.png"),(snake_block*3, snake_block*3))
magnet_ico = pygame.transform.scale(pygame.image.load("graphics/magnet_ico.png"), (snake_block*3, snake_block*3))
reverse_ico = pygame.transform.scale(pygame.image.load("graphics/reverse_ico.png"), (snake_block*3, snake_block*3))
freeze_ico = pygame.transform.scale(pygame.image.load("graphics/freeze_ico.png"), (snake_block*3, snake_block*3))

pommeV_ico = pygame.transform.scale(pygame.image.load("graphics/pommeV_ico.png"), (snake_block, snake_block))
pommeR_ico = pygame.transform.scale(pygame.image.load("graphics/pommeR_ico.png"), (snake_block, snake_block))

snake1_ico = pygame.transform.scale(pygame.image.load("graphics/python_ico.png"), (snake_block*2, snake_block*2))
snake2_ico = pygame.transform.scale(pygame.image.load("graphics/python_ico.png"), (snake_block*2, snake_block*2))

# Audio 
mixer.init()
eating_sound = mixer.Sound('sounds/crunch.wav')
powerup_sound = mixer.Sound('sounds/powerup.wav')
# Load main theme 
if game_music_name == "retro" :
    game_theme_music_path = "retro_theme.wav" 
else :
    game_theme_music_path = game_music_name+"_theme.mp3"
game_theme_music_path = "sounds/"+game_theme_music_path
pygame.mixer.music.load(game_theme_music_path)


# Modifiers
powerup_types = [{'name': 'invincible', 'color': grey, 'duration': 10, 'icon': shield_ico},
                 {'name': 'speed boost', 'color': yellow, 'duration': 7, 'icon': speed_ico},
                 {'name': 'growth multiplier', 'color': green_bonus, 'duration': 8, 'icon': growth_ico},
                 {'name': 'magnet', 'color': red, 'duration': 10, 'icon': magnet_ico},
                 {'name': 'reverse', 'color': purple, 'duration': 5, 'icon': reverse_ico},
                 {'name': 'freeze', 'color': blue_freeze, 'duration': 5, 'icon': freeze_ico}]


def message(msg, color):
    mesg = font_end.render(msg, True, color)
    dis.blit(mesg, [display_width / 4, display_height / 3])
    
def show_scores(Length_of_snake1,Length_of_snake2,font_score, final=False, font_win=font_win):
    # Update scores
    score1 = Length_of_snake1
    score2 = Length_of_snake2
    
    # Draw scores on top of screen
    text_score1 = font_score.render(f"Black Score: {score1}", True, white)
    text_score2 = font_score.render(f"White Score: {score2}", True, white)
    dis.blit(text_score2, (10, 10))
    dis.blit(text_score1, (display_width - text_score2.get_width() - 10, 10))

    if final :
        # Update scores
        score1 = global_score_B
        score2 = global_score_W
        
        # Draw scores on top of screen
        text_win1 = font_win.render(f"Black Wins: {score1}", True, white)
        text_win2 = font_win.render(f"White Wins: {score2}", True, white)
        dis.blit(text_win2, (30, 30))
        dis.blit(text_win1, (display_width - text_score2.get_width() - 90, 30))
            

def show_timer(player, color, time_left, name="-"):
    # Show Power up name :
    type = font_win.render(f"{name}", True, color)

    font_style = pygame.font.SysFont(None, 80)
    timer_text = str(int(time_left)).zfill(2)
    time = font_style.render(timer_text, True, color)
    if player == 'Black':
        dis.blit(time, (display_width - time.get_width() - 10, 50))
        dis.blit(type, (display_width - type.get_width() - 10, 100))
    else:
        dis.blit(time, (10, 50))
        dis.blit(type, (10, 100))

def show_game_timer(time_left):
    # Show time left if time mode activated 
    if 'time' in game_mode:
        font_style = pygame.font.SysFont(None, 80)
        timer_text = str(int(time_left)).zfill(2)
        time = font_style.render(timer_text, True, red)
        dis.blit(time, (display_width//2, 30))
     
def gameLoop():

    global global_score_B 
    global global_score_W

    pygame.mixer.music.play(-1) 
    pygame.mixer.music.set_volume(music_volume)
    #print("Game Loop")
    game_over = False
    game_close = False

    #print(" Player 1 Snake")
    x1 = 3*display_width / 4
    y1 = 3*display_height / 4
    x1_change = 0
    y1_change = 0
    snake_state1 = 'normal'
    snake_List1 = []
    Length_of_snake1 = 1
    # Power up variators
    growth_multiplier1 = 1
    magnet1 = 1
    P1_control_variation = 1
    P1_movement_variation = 1


    #print(" Player 2 Snake")
    x2 = display_width / 4
    y2 = display_height / 4
    x2_change = 0
    y2_change = 0
    snake_state2 = 'normal'
    snake_List2 = []
    Length_of_snake2 = 1
    # Power up variators
    growth_multiplier2 = 1
    magnet2 = 1
    P2_control_variation = 1
    P2_movement_variation = 1
    

    #print(" Food")
    foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block

    food2x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    food2y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
    food2_exist = True

    foodRx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
    foodRy = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
    foodR_exist = True
    
    #print(" Power ups")
    powerup_chance = 0.05
    powerup_timer = 0
    power_up_name = ''
    POWERUP_DURATION = 0 
    powerup_active = False
    powerup_type = None
    powerup_x = None
    powerup_y = None
    powerup_time1 = None
    powerup_time2 = None

    # Set up font objects
    font_score = pygame.font.SysFont(None, 25)
    font_winner = pygame.font.SysFont(None, 30)
    
    # Set up timer 
    start_time = time.time()
    max_time = 60*snake_block

    winner = ""
    while not game_over:
        while game_close:
            #dis.fill(blue)
            message(winner+" Player Wins! Press E-Exit or C-Play Again", red)
            show_scores(Length_of_snake1,Length_of_snake2,font_score, final=True)
            pygame.mixer.music.stop()
            pygame.display.update()

            events =  pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    game_over = True
                    game_close = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_e:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        gameLoop()
                        
        #print(" Handle events")
        events = [event for event in pygame.event.get() if event.type == pygame.QUIT or event.type == pygame.KEYDOWN]
        quit_event = [event for event in events if event.type == pygame.QUIT]
        keysP1 = [pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN]
        keysP2 = [pygame.K_z, pygame.K_q, pygame.K_s, pygame.K_d]
        eventP1 = [event for event in events if event.type != pygame.QUIT and event.key in keysP1][-1:]
        eventP2 = [event for event in events if event.type != pygame.QUIT and event.key in keysP2][-1:]
        handled_events = quit_event + eventP1 + eventP2
        for event in handled_events:
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q and x2_change == 0:
                    x2_change = -snake_block*P2_control_variation
                    y2_change = 0
                elif event.key == pygame.K_d and x2_change == 0:
                    x2_change = snake_block*P2_control_variation
                    y2_change = 0
                elif event.key == pygame.K_z and y2_change == 0:
                    y2_change = -snake_block*P2_control_variation
                    x2_change = 0
                elif event.key == pygame.K_s and y2_change == 0:
                    y2_change = snake_block*P2_control_variation
                    x2_change = 0
                elif event.key == pygame.K_LEFT and x1_change == 0:
                    x1_change = -snake_block*P1_control_variation
                    y1_change = 0
                elif event.key == pygame.K_RIGHT and x1_change == 0:
                    x1_change = snake_block*P1_control_variation
                    y1_change = 0
                elif event.key == pygame.K_UP and y1_change == 0:
                    y1_change = -snake_block*P1_control_variation
                    x1_change = 0
                elif event.key == pygame.K_DOWN and y1_change == 0:
                    y1_change = snake_block*P1_control_variation
                    x1_change = 0
                    
        #print("Power ups")
        if not powerup_active and random.random() < powerup_chance:
            powerup_type = random.choice(powerup_types)
            powerup_x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            powerup_y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            powerup_active = True
            power_up_name = powerup_type['name']
            power_up_color = powerup_type['color']
            powerup_icon = powerup_type['icon']
            powerup_timer = powerup_type['duration'] * snake_speed
            POWERUP_DURATION = powerup_type['duration'] 

        if 'infinity' not in game_mode :
            #print(" check for out of bounds for player 1 (only in classic mode)")
            if x1 >= display_width or x1 < 0 or y1 >= display_height or y1 < 0 and 'invincible' not in snake_state1 :
                game_close = True
                winner = "White"
                global_score_W += 1
            #print(" check for out of bounds for player 2")
            if x2 >= display_width or x2 < 0 or y2 >= display_height or y2 < 0 and 'invincible' not in snake_state2 :
                game_close = True
                winner = "Black"
                global_score_B += 1

        
        x1 += P1_movement_variation*x1_change
        y1 += P1_movement_variation*y1_change
        x2 += P2_movement_variation*x2_change
        y2 += P2_movement_variation*y2_change

        if 'infinity' in game_mode :
            # Wrap around the screen for player 1
            x1 %= display_width
            y1 %= display_height
            # Wrap around the screen for player 2
            x2 %= display_width
            y2 %= display_height

        dis.fill(blue)
        max_time -= 1
        show_game_timer((max_time - (time.time()-start_time))//snake_block)


        #print(" draw food on the screen")
        #pygame.draw.rect(dis, green1, [foodx, foody, snake_block, snake_block])
        #pygame.draw.rect(dis, green2, [food2x, food2y, snake_block, snake_block])
        dis.blit(pommeV_ico, (foodx, foody))
        dis.blit(pommeV_ico, (food2x, food2y))
        dis.blit(pommeR_ico, (foodRx, foodRy))
        

        #print(" handle power ups")
        #if powerup_active and powerup_type != None:
        #    pygame.draw.rect(dis, powerup_type['color'], [powerup_x, powerup_y, snake_block, snake_block])
        if powerup_active and powerup_type != None:
            dis.blit(powerup_icon, (powerup_x-snake_block, powerup_y-snake_block))
            

            powerup_timer -= 1
            if powerup_timer <= 0:
                powerup_active = False
                powerup_type = None

            if abs(x1 - powerup_x) < magnet1*2*snake_block and abs(y1 - powerup_y) < magnet1*2*snake_block and powerup_active:
                powerup_time1 = time.time()  # set power-up time for player 1
                powerup_sound.play()
                if powerup_type['name'] == 'invincible':
                    snake_state1 += 'invincible'
                elif powerup_type['name'] == 'speed boost':
                    snake_state1 = 'speed boost'
                    P1_movement_variation *=2
                    magnet1 = 2
                elif powerup_type['name'] == 'growth multiplier':
                    growth_multiplier1 = 3
                elif powerup_type['name'] == 'magnet':
                    magnet1 = 5
                elif powerup_type['name'] == 'reverse':
                    P2_control_variation *= -1
                elif powerup_type['name'] == 'freeze':
                    P2_movement_variation = 0
                    snake_state2 += 'invincible'
                powerup_type = None
            elif abs(x2 - powerup_x) < magnet2*2*snake_block and abs(y2 - powerup_y) < magnet2*2*snake_block and powerup_active:
                powerup_time2 = time.time()  # set power-up time for player 2
                powerup_sound.play()
                if powerup_type['name'] == 'invincible':
                    snake_state2 += 'invincible'
                elif powerup_type['name'] == 'speed boost':
                    snake_state2 = 'speed boost'
                    P2_movement_variation *=2
                    magnet2 = 2
                elif powerup_type['name'] == 'growth multiplier':
                    growth_multiplier2 = 3
                elif powerup_type['name'] == 'magnet':
                    magnet2 = 5
                elif powerup_type['name'] == 'reverse':
                    P1_control_variation *= -1
                elif powerup_type['name'] == 'freeze':
                    P1_movement_variation = 0
                    snake_state1 += 'invincible'
                powerup_type = None

        # check power-up effect duration for player 1
        if powerup_time1 is not None and time.time() - powerup_time1 >= POWERUP_DURATION:
            snake_state1 = 'normal'
            snake_state2 = 'normal'
            powerup_time1 = None
            powerup_active = False
            growth_multiplier1 = 1
            magnet1 = 1
            P1_control_variation = 1
            P2_control_variation = 1
            P1_movement_variation = 1
            P2_movement_variation = 1
        
        # check power-up effect duration for player 2
        if powerup_time2 is not None and time.time() - powerup_time2 >= POWERUP_DURATION:
            snake_state2 = 'normal'
            snake_state1 = 'normal'
            powerup_time2 = None
            powerup_active = False
            growth_multiplier2 = 1
            magnet2 = 1
            P1_control_variation = 1
            P2_control_variation = 1
            P1_movement_variation =1
            P2_movement_variation =1
            

        if 'god' in game_mode:
            if 'invincible' not in snake_state1 :
                snake_state1 += 'invincible'
            if 'invincible' not in snake_state2 :
                snake_state2 += 'invincible'

        # show power-up timer if active
        if powerup_active and powerup_time1 is not None:
            show_timer('Black',power_up_color,POWERUP_DURATION - (time.time() - powerup_time1), name=power_up_name)
        elif powerup_active and powerup_time2 is not None:
            show_timer('White',power_up_color,POWERUP_DURATION - (time.time() - powerup_time2), name=power_up_name)
            
        #print(" update snake 1 and check for collision with player 2")
        if P1_movement_variation != 0 :
            snake_Head1 = [x1, y1]
            snake_List1.append(snake_Head1)

        while len(snake_List1) > Length_of_snake1:
            del snake_List1[0]
            
        for x in snake_List1[:-1]:
            if x == snake_Head1 and 'invincible' not in snake_state1 :
                    game_close = True
                    winner = "White"
                    global_score_W += 1
        for x in snake_List2[:-1]:
            if x == snake_Head1 and 'invincible' not in snake_state1 :
                    game_close = True
                    winner = "White"
                    global_score_W += 1

        for x in snake_List1:
            pygame.draw.rect(dis, black, [x[0], x[1], snake_block, snake_block])
        dis.blit(snake1_ico, (x1-snake_block//2, y1-snake_block//2))

        #print(" update snake 2 and check for collision with player 1")
        if P2_movement_variation != 0 :
            snake_Head2 = [x2, y2]
            snake_List2.append(snake_Head2)

        while len(snake_List2) > Length_of_snake2:
            del snake_List2[0]

        for x in snake_List2[:-1]:
            if x == snake_Head2 and 'invincible' not in snake_state2 :
                    game_close = True
                    winner = "Black"
                    global_score_B += 1
        for x in snake_List1[:-1]:
            if x == snake_Head2 and 'invincible' not in snake_state2 :
                    game_close = True
                    winner = "Black"
                    global_score_B += 1
                    

        for x in snake_List2:
            pygame.draw.rect(dis, white, [x[0], x[1], snake_block, snake_block])
        dis.blit(snake2_ico, (x2-snake_block//2, y2-snake_block//2))
        # Update scores
        show_scores(Length_of_snake1,Length_of_snake2,font_score)

        #print(" update display")
        pygame.display.update()
        
        #print(" check for food collision for player 1")
        if abs(x1 - foodx) < magnet1*snake_block and abs(y1 - foody) < magnet1*snake_block:
            foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            eating_sound.play()
            Length_of_snake1 += growth_multiplier1*3

        #print(" check for food collision for player 2")
        if abs(x2 - foodx) < magnet2*snake_block and abs(y2 - foody) < magnet2*snake_block:
            foodx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foody = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            eating_sound.play()
            Length_of_snake2 += growth_multiplier2*3

        if food2_exist:
            if abs(x1 - food2x) < magnet1*snake_block and abs(y1 - food2y) < magnet1*snake_block:
                food2_exist = False
                eating_sound.play()
                Length_of_snake1 += growth_multiplier1*3

            if abs(x2 - food2x) < magnet2*snake_block and abs(y2 - food2y) < magnet2*snake_block:
                food2_exist = False
                eating_sound.play()
                Length_of_snake2 += growth_multiplier2*3

        if foodR_exist:
            if abs(x1 - foodRx) < magnet1*snake_block and abs(y1 - foodRy) < magnet1*snake_block and 'invincible' not in snake_state2 :
                foodR_exist = False
                eating_sound.play()
                Length_of_snake2 = max(1,Length_of_snake2-(max(1,growth_multiplier1-1))*2)

            if abs(x2 - foodRx) < magnet2*snake_block and abs(y2 - foodRy) < magnet2*snake_block and 'invincible' not in snake_state1 :
                foodR_exist = False
                eating_sound.play()
                Length_of_snake1 = max(1,Length_of_snake1-(max(1,growth_multiplier2-1))*2) 
                
        if not food2_exist:
            food2x = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            food2y = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            food2_exist = True
        
        if not foodR_exist:
            foodRx = round(random.randrange(0, display_width - snake_block) / snake_block) * snake_block
            foodRy = round(random.randrange(0, display_height - snake_block) / snake_block) * snake_block
            foodR_exist = True
                
        #print(" check for collision between snake heads")
        if x1 == x2 and y1 == y2 and 'invincible' not in snake_state1  and 'invincible' not in snake_state2 :
            if Length_of_snake1 > Length_of_snake2 :
                winner = 'Black'
                global_score_B +=1
            elif Length_of_snake1 < Length_of_snake2 :
                winner = 'White'
                global_score_W +=1
            else :
                winner = "No"
            game_close = True
            
        clock.tick(snake_speed)

        

    pygame.quit()
gameLoop()
